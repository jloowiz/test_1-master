import 'package:flutter/material.dart';

class JeepneysPage extends StatefulWidget {
  const JeepneysPage({super.key});

  @override
  _JeepneysPageState createState() => _JeepneysPageState();
}

class _JeepneysPageState extends State<JeepneysPage> {
  String selectedStatus = 'None';

  final List<Map<String, dynamic>> jeepneys = [
    {
      'name': 'Jeepney 1',
      'description': 'Route: Balibago - Dau Terminal, Capacity: 16',
      'fare': 10.0,
      'isExpanded': false,
    },
    {
      'name': 'Jeepney 2',
      'description': 'Route: Angeles - Clark, Capacity: 18',
      'fare': 12.0,
      'isExpanded': false,
    },
    {
      'name': 'Jeepney 3',
      'description': 'Route: Marquee - Nepo Mall, Capacity: 15',
      'fare': 11.0,
      'isExpanded': false,
    },
    {
      'name': 'Jeepney 4',
      'description': 'Route: Dau Terminal - SM Clark, Capacity: 20',
      'fare': 13.0,
      'isExpanded': false,
    },
  ];

  void _toggleExpansion(int index) {
    setState(() {
      jeepneys[index]['isExpanded'] = !jeepneys[index]['isExpanded'];
    });
  }

  double _calculateFare(double fare) {
    switch (selectedStatus) {
      case 'Student':
      case 'Senior Citizen':
        return fare - 2;
      default:
        return fare;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color.fromARGB(255, 0, 1, 85), Colors.black],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: ListView.builder(
            itemCount: jeepneys.length,
            itemBuilder: (context, index) {
              final jeepney = jeepneys[index];
              return Padding(
                padding: const EdgeInsets.only(bottom: 16.0),
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15),
                    boxShadow: const [
                      BoxShadow(
                        color: Color.fromARGB(255, 2, 0, 94),
                        blurRadius: 10,
                        offset: Offset(0, 5),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      ListTile(
                        contentPadding: const EdgeInsets.all(16),
                        title: Text(
                          jeepney['name'],
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        subtitle: Text(
                          jeepney['description'],
                          style: const TextStyle(fontSize: 16),
                        ),
                        leading: const Icon(Icons.directions_bus, color: Color.fromARGB(255, 2, 0, 94)),
                        trailing: Icon(
                          jeepney['isExpanded'] ? Icons.expand_less : Icons.expand_more,
                        ),
                        onTap: () => _toggleExpansion(index),
                      ),
                      if (jeepney['isExpanded'])
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Select Discount:',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black87,
                                ),
                              ),
                              const SizedBox(height: 10),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                children: [
                                  ChoiceChip(
                                    label: const Text(
                                      'Student',
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    selected: selectedStatus == 'Student',
                                    onSelected: (bool selected) {
                                      setState(() {
                                        selectedStatus = selected ? 'Student' : 'None';
                                      });
                                    },
                                    selectedColor: Colors.blueGrey,
                                  ),
                                  ChoiceChip(
                                    label: const Text(
                                      'Senior Citizen',
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    selected: selectedStatus == 'Senior Citizen',
                                    onSelected: (bool selected) {
                                      setState(() {
                                        selectedStatus = selected ? 'Senior Citizen' : 'None';
                                      });
                                    },
                                    selectedColor: Colors.blueGrey,
                                  ),
                                  ChoiceChip(
                                    label: const Text(
                                      'None',
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    selected: selectedStatus == 'None',
                                    onSelected: (bool selected) {
                                      setState(() {
                                        selectedStatus = selected ? 'None' : selectedStatus;
                                      });
                                    },
                                    selectedColor: Colors.blueGrey,
                                  ),
                                ],
                              ),
                              const SizedBox(height: 10),
                              Text(
                                'Fare: ₱${_calculateFare(jeepney['fare']).toStringAsFixed(2)}',
                                style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black,
                                ),
                              ),
                            ],
                          ),
                        ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}